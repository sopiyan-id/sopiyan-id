# Website Pribadi — SOPIYAN, S.I.P.

Website statis berbahasa Indonesia dengan desain biru-putih, responsif untuk ponsel dan desktop.

## Menjalankan di komputer
1. Ekstrak ZIP.
2. Buka `index.html` di browser.

## Publikasi gratis menggunakan GitHub Pages
1. Masuk atau daftar di https://github.com/
2. Buat repository baru bernama `username.github.io` (ganti `username` dengan nama pengguna GitHub Anda).
3. Unggah file `index.html` ke repository tersebut. Anda juga dapat mengunggah `README.md`.
4. Jika memakai repository bernama lain: buka **Settings → Pages**, pilih **Deploy from a branch**, pilih branch `main` dan folder `/ (root)`, lalu simpan.
5. Tunggu proses publikasi selesai. Alamat website akan terlihat di bagian **Settings → Pages**.

## Sebelum dipublikasikan
- Periksa kembali semua data profil agar akurat.
- Avatar “SP” adalah pengganti sementara; bisa diganti dengan foto pribadi.
- Ganti tautan `href="mailto:"` di tombol kontak dengan alamat email Anda.
- Tambahkan tautan media sosial hanya jika memang ingin ditampilkan.

Website ini tidak membutuhkan framework atau instalasi tambahan.
